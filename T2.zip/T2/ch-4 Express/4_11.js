var express = require("express");

var app = express();

const lock = (req, res, next) => {
    console.log("Coming......");
    next();
};

const checkID = (req, res, next) => {
    const ID = true;
    // const ID = false;

    if (ID) {
        // assign value properly
        req.name = "Student";   // you were using req.name later
        console.log("Welcome");
        next();
    } else {
        console.log("Go Back denied");
        res.send("Access denied");   // response required
    }
};

app.use("/student", lock, checkID);

app.get("/student", (req, res) => {
    res.send("Welcome: " + req.name);
});

app.listen(4011);


console.log("http://localhost:4011/student")