var express = require("express")

var app = express()


app.get("/data",(req,res)=>{
    const name=req.query.name;
    const age= req.query.age;


    res.send("Name:"+name+"Age:"+age)
})
app.listen(4006)



// http://localhost:4006/data?name=Don&age=16