users = { "name": "abc", "age": 20 }

var express = require("express")

var app = express()


app.use(express.urlencoded({ extended: true }));
app.post('/users', (req, res) => {
const name = req.body.name;
const age = req.body.age;
res.send("Name: " + name + ", Age: " + age);
});

app.listen(4007)


// http://localhost:4007/users?name=Don&age=16


