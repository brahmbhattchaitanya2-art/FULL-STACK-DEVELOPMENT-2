// Route parameter

var express = require("express")

var app = express()

app.get("/calendar/:day/event/:ename",(req,res)=>{
    res.send(req.params) // day and ename from the URL 
})
app.listen(4005)


// http://localhost:4005/calendar/monday/event/party