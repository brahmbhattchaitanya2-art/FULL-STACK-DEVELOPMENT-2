//create web server that 
//1)except a get request with dynamic userid in url
//2)also except additional data like name and age using query parameter 
//3)extact id from root parameter and name and age from query string 
//4)return a json response containig all received data 

var express = require('express');
var app = express();
app.get("/user/:id",(req,res)=>{
    const userid = req.params.id;
    const name = req.query.name;
    const age = req.query.age;
    res.json({ "message":"data received",
        "params": { "userid": userid },
        "query":{ name,age }
    });
})
app.listen(5500)



// http://localhost:5500/user/101?name=Dev&age=20