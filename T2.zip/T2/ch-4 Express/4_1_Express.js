var express = require("express")
var app = express();
app.get("/",function(req,res)
{
    res.set("context","text/plain")
    res.send("Hello World.")
});
app.listen(5001)