student = { name: "Hello", age: 28 }
var express = require("express")
var app = express();
app.get("/", function (req, res) {
     
    
    res.write(JSON.stringify(student.age))
// res.write(student.age.toString())




    // res.send(student)
    // res.json(student.age)
   
})
app.listen(1245)
