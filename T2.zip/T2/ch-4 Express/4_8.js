// For Post method:-
//ceate a web application,
//1) display a form on home page to enter users name 
//2)send the form data to the server using post method 
//3)the server should read the submitted name from request body 
//4)finally display a confirm message 
var express = require('express');
var app = express();
app.use(express.urlencoded({ extended: true }));

app.get("/", (req, res) => {
    res.send(`
        <h1>Form</h1>
        <form action="/user" method="post">
            <input type="text" name="name" placeholder="Enter name">
            <input type="submit">
        </form>
    `);
});

app.post("/user", (req, res) => {
    const name = req.body.name;
    res.send("User entered with " + name);
});

app.listen(778)