var express = require("express")
var app = express();
app.get("/", function (req, res)
    {
        res.set("Content-Type", "text/plain")
    res.send("<h1>Hello World.</h1>")
    });

app.get("/about", function (req, res)

    {
        res.set("Content-Type", "text/html")
    // res.write("Hello")
    res.send("bye")
    // res.send()
    });

app.listen(5001)