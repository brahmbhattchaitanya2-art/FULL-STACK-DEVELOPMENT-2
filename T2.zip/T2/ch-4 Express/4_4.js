//write an express js script to define one 
// json array of three objects having properties name and age sort 
// this object according to age 
// if user request the sorted name in url than all the names along with the age
//  should be printed according to descending order of page , 
// also display this sorted values on sort page and display the json object on home page
var express = require('express');
var app = express();
Students = [{ "name": "abc", "age": 20 }, { "name": "def", "age": 30 }, { "name": "ghi", "age": 25 }]
app.get("/", (req, res) => {
    res.send(Students);
})
app.get("/sort", (req, res) => {
    res.set("Content-Type", "text/html");
    var des = Students.sort((a, b) => b.age - a.age);
    for (k of des) {
        res.write("<h2>" + k.name + "= " + k.age + "</h2>");
    }
    res.send()
}).listen(668)