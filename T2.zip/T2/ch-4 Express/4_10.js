// create a application where 1 multplie middle warw function add students name , colleg ,marks as data
// 2 data is pass as useing req last 3 final route path that display all value in line



// Create an application using Express.js where: 
// • Multiple middleware functions add student name, college, and marks  
// • Data is passed using req  
// • Final route displays all values 





var express = require("express")

var app = express()


const addN = (req, res, next) => {
    req.name = "Om"
    console.log("Name Added");
    next();
}




const addcol = (req, res, next) => {
    req.college = "Nirma"
    console.log("Clg Added");
    next();
}




const addM = (req, res, next) => {
    req.total = 50 + 40
    console.log("Marked Added");
    next();
}




app.get("/student", addN, addcol, addM, (req, res) => {

    res.send("Student Name:" + req.name + "<br>College:" + req.college + "<br>Total Marks:" + req.total)
})
app.listen(4010,()=>{
    console.log("http://localhost:4010/student");

});




