var express = require("express");
var app = express();

app.use(express.static(__dirname, { index: "form.html" }));

app.use(express.urlencoded({ extended: true }));

app.post("/process", (req, res) => {
    const name = req.body.n1;
    const sur = req.body.n2;

    res.json({
        "message": "data received",
        "name": name,
        "surname": sur
    });
});

app.listen(8587);