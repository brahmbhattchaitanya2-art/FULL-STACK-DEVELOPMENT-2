var express = require("express");

var app = express();

app.use(express.static(__dirname, { index: "index_1.html" }))

app.get("/process_get", function (req, res) {
    var fn = req.query.first_name;
    var ln = req.query.last_name;

    res.json({
        "message": "data received",

        "query": { fn, ln }
    });

    res.send(`welcome ${fn}${ln}`)


})
app.listen(4013);