// Write a Node.js program using Express and express-session to meet the following requirements:

// 1. Create an index.html file that contains a login form
//    with fields: username, password, and a login button.

// 2. When the user clicks the submit button,
//    the request should go to a route that saves the session.

// 3. After saving the session, redirect to a page
//    that fetches and displays the stored session data (username and password).

// 4. On that page, provide a logout link.

// 5. When the logout link is clicked,
//    it should go to a route that destroys the session.

// 6. After destroying the session,
//    redirect the user back to the login (index.html) page.



// const express = require("express");
// const app = express();
// const sess = require("express-session");

// // Session configuration
// app.use(sess({
//     resave: true,
//     saveUninitialized: true,
//     secret: "123",
//     name: "Dev",
// }));


// app.use(express.static(__dirname));


// app.get("/sess", (req, res) => {
//     req.session.n1 = req.query.n1;
//     res.redirect("/fetch");
// });

// app.get("/fetch", (req, res) => {
//     if (req.session.n1) {
//         res.send(`
//             <h1 style="color:blue">Welcome ${req.session.n1} to our website</h1>
//             <a href="/delete">Logout</a>
//         `);
//     } else {
//         res.redirect("/");
//     }
// });


// app.get("/delete", (req, res) => {
//     req.session.destroy()

//     res.redirect("/");
// });


// app.listen(9955, () => {
//     console.log("Server running at http://localhost:9955");
// });


// write a script to meet following requirements: 
// • Create index.html file page which contains form(username,password,login button). 
// and open it on localhost.  
// • After clicking submit button, it should jump on “savesession” page. Store username 
// and password in session. 
// • After saving session, redirect to “fetchsession” page and read value. Put a LOGOUT 
// link here. 
// • Jump on delete session page after clicking LOGOUT link.  
// • Destroy the session on this page and redirect to index.html page.


var express = require("express");
var app = express();
var es = require("express-session");
app.use(es({
    resave: false,
    saveUninitialized: false,
    secret: "lju1"
}));
app.use(express.static(__dirname,{index:"5.11.html"}));
app.get("/savesession", (req, res) => {
    req.session.uname = req.query.uname;
    req.session.password = req.query.password;
    res.redirect("fetchsession")
})
app.get("/fetchsession", (req, res) => {
    res.write("<h1>Welcome " + req.session.uname + "</h1>")
    res.write("<a href='/deletesession'>Logout</a>")
    res.send();
});
app.get("/deletesession", (req, res) => {
    req.session.destroy()
    res.redirect('/')
});
app.listen(6177);