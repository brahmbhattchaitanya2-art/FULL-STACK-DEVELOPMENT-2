//Session
const express = require("express");
const app = express();

const sess = require("express-session")



app.use(sess(
    {
        resave: true,
        saveUninitialized: true,
        secret: "123",
        name: "Dev",
    }
))
app.get("/", (req,res) => {
    if (req.session.page_views) {
        req.session.page_views++;
        res.send(`<h1 style="color:blue">You have visited page${req.session.page_views}times`);
    }
    else {
        req.session.page_views = 1;
        res.send(`<h1 style="color:green">Weclome! Thank you for visiting our website!</h1>`);


    }
})
app.listen(9944)