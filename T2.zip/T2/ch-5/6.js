// built exp js app with 1 html form having user name password and submit btn using post method
//2on  visiting the home display the form pg
//3  on submiting the form / login pg shuold be diplays a) if user name if admin diplay weclome admin
//b) else show "please login with admine  name " and a link that to be form




var express = require("express")
var app = express();

app.use(express.static(__dirname, { index:'3.html' }))



app.use(express.urlencoded({ extended: true }))

app.post("/login", (req, res) => {
    const name = req.body.n1;
    const password = req.body.n2;

    if(name==="admin")
        res.send("Weclome BOSS")
    else
        res.send(`<a href="/">Please Login with ADMIN NAME!!!!</a>`)
res.send()



});
app.listen(5587)
