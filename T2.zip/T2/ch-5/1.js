var express= require("express");
var app= express();

// 




// app.use(express.static(__dirname))//index file is automatic call by default but if you not give file name  index so mention that file name 


// app.use(express.static("frontend"))



const path=require("path")

const sp =path.join(__dirname,"../frontend")

app.use(express.static(sp))




app.listen(4111)
