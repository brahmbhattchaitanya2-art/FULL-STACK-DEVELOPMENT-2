//write express js script to perform as ask below
// 1 crate 1 html form that contain 2 no. type input ,1 dropdown whcich conatain option like (+,-,* and /)and sumbit btn

//2 condition the input field contaion must 0 greater else msg please enter valid number
// user must slect from the dropdown else it will gib=ve a msg you will not sleect 
//3 if 1 formula are select then the rescptive calculation will perform on pg "/cal" USE get method only



var express = require("express")
var app = express();
app.use(express.static(__dirname, { index: 'cal.html' }))
app.get("/calc", function (req, res) {

    var n1 = parseInt(req.query.n1)
    var n2 = parseInt(req.query.n2)
    var operation = req.query.Calculate
    if (n1 > 0 && n2 > 0) {
        if (operation === "ADD") {
            res.send("Result:"+ (n1 + n2))
        }

        else if (operation === "SUB") {
            res.send("Result:"+ (n1 - n2))

        }


        else if (operation === "MUL") {
            res.send("Result:"+(n1 * n2))

        }


        else if (operation === "DIV") {
            res.send("Result:"+ (n1 / n2))

        }
        else {
            res.send("please enter valid number")
        }

    }

});
app.listen(5760)
