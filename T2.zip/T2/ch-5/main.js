const exp =require("express")
const app=exp()
const api= require("./api")
app.use("/api",api)
app.listen(7997, () => {
    console.log("Server running at http://localhost:7997/api")
     console.log("Server running at http://localhost:7997/api/101")
     console.log("http://localhost:7997/api/branch/it")
});





