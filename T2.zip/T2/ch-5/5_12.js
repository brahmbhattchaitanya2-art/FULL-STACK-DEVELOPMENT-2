// write js after save session direct to fetxch data pg and read value.on this pg check authoduication of user. user name and pass is admin and admin123 respective
// a if this codition is true weclome admin and logout link on this pg
//by clicking on logout link uswer must jump to destroy pg and seesion shld destroy and display msg seesion destroye
//and give a link of login pg under it
// else display a msg plz enyter valid user ans=d password and login link

const express = require("express");
const app = express();
const sess = require("express-session");

app.use(sess({
    resave: true,
    saveUninitialized: true,
    secret: "123",
    name: "Dev",
}));

app.use(express.static(__dirname));

app.get("/sess", (req, res) => {
    req.session.n1 = req.query.n1; 
    req.session.n2 = req.query.n2;
    res.redirect("/fetch");        
});

app.get("/fetch", (req, res) => {
    if (req.session.n1 === "admin" && req.session.n2 === "admin123") {
        res.send(`Welcome BOSS <br><a href="/delete">Logout</a>`);
    } else {
        res.send(`Please enter valid username and password <br><a href="/">Login</a>`);
    }
});

app.get("/delete", (req, res) => {
    req.session.destroy(() => {
        res.send(`Session Destroyed <br><a href="/">Login Page</a>`);
    });
});

app.listen(9966, () => {
    console.log("Server running at http://localhost:9966");
});