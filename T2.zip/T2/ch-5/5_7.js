const express = require("express");

const app = express();

const cp = require("cookie-parser")

app.use(cp()) //middle ware for jump

// data stored on browser (client side)



app.get("/",(req,res)=>{
    res.cookie("name","ExpressTS")
    res.cookie("fname","Chaitanya")
    res.cookie("lname","Rao")

    res.cookie("ID","2",{expires:new Date(Date.now()+10000)})// displayed for 10 seconds {maxAge:10000} can be used as well 

    res.cookie("email","roa@gmail.com",{maxAge:2000})// will be displayed for 3 seconds on browser

    res.clearCookie("name")//it will be cleared and not displayed on the browser

    res.send(req.cookies)
})
app.listen(5004)
