
//write express js script to set cookies of submit value of form perform followinhg task 
//1 create html file thate contain form having fname laname pass and submit btn .
// 2 once form is submited store all value to respective cookie on next / page .
//3 then redirect user to / admin pg and clear the cookie set for last name .display remaining set cookie value on this pg  USE POST method only



const express = require("express");

const app = express();

const cp = require("cookie-parser")

app.use(cp())
app.use(express.urlencoded({ extended: true }))

app.use(express.static(__dirname, { index: "5_5.html" }));

app.post("/next", (req, res) => {
    res.cookie("Fname", req.body.name)
    res.cookie("Last", req.body.last)
    res.cookie("password", req.body.password)
    res.redirect('/admin')


})


app.get('/admin', (req, res) => {


    res.clearCookie("Last")//it will be cleared and not displayed on the browser

    res.send(req.cookies)


});



app.listen(5005)
