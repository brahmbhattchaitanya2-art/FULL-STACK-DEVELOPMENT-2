 //write exp js script to print msg in nxt line splitting by "." . and use get method to submit the data
// note html file contain textarea for the msg and submit btn

var express = require("express");

var app = express();

app.use(express.static(__dirname, { index: "3js.html" }))

app.get("/process_get", function (req, res) {

    var tx = req.query.message;
    res.send(JSON.stringify(tx.split(".")))


})
app.listen(4014);