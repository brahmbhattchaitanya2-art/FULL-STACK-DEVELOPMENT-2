const express = require("express")
const multer = require("multer")
const app = express()

app.use(express.static(__dirname, { index: "m1.html" }))

var store = multer.diskStorage({
    destination: "Lju",
    filename: function (req, file, cb) { cb(null, file.originalname) }
})
var upload = multer({ storage: store })

app.post("/upload", upload.single('mypic'), (req, res) => {
    const file = req.file
    if (file) {
        res.send("<h1>file<span style='color:red'>" + file.originalname + "'</span>has been uploaded in <span style='color:red'>'" + file.destination + "</span>folder")
    }
})
app.listen(6001)