// creat html file for response form that shoulde n=be loaded on home pg the field are name,email,and submit btn.
//once form is submiitted show msg "thank 4 u respnse " which will diplay on pg /respnse and also send email on enter email id with the submiited response


const express = require("express");
const nodemailer = require("nodemailer");

const app = express();
app.use(express.urlencoded({ extended: true }));


app.get("/", (req, res) => {
    res.sendFile(__dirname + "/6_5.html");
});


app.post("/response", (req, res) => {
    const { name, email } = req.body;

    let transporter = nodemailer.createTransport({
        service: "smtp.gmail.com",
        auth: {
            user: "shichan132@gmail.com",
            pass: "bsjq fvhn htev mktu"
        }
    });

    transporter.sendMail({
        from: "shichan132@gmail.com",
        to: "dkdk14383@gmail.com",
        subject: "Response Received",
        text: `Thank you ${name} for your response.`
    });

    res.send("<h3>Thank you for your response.</h3>");
});

app.listen(3000);