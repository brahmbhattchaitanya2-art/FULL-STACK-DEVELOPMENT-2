const express = require("express");
const multer = require("multer");

const app = express();
app.use(express.static(__dirname, { index: "6_3.html" }))

// storage config
const storage = multer.diskStorage({
    destination: "data",
    filename: function (req, file, cb) {
        // cb(null, "LJU-file-pdf");
        cb(null, file.fieldname+"-"+"LJU-file.pdf");
    }
});

// multer with 10MB limit
const upload = multer({
    storage: storage,
    limits: { fileSize: 10 * 1024 * 1024 }
});

// upload route
app.post("/upload", upload.single("mypic"), (req, res) => {
    res.send("File uploaded");
});

app.listen(6002);