const ejs = require("ejs");
const express = require("express");

const app = express();

app.set("view engine", "ejs")

app.use(express.urlencoded())

// app.get("/contact",(req,res)=>{
//     res.render("contact")
// })

app.get("/",(req,res)=>{
    res.render("contact")
})

app.post("/submit",(req,res)=>{
    const email = req.body.email
    const name = req.body.fname
    const m1 = Number(req.body.m1);
    const m2 = Number(req.body.m2);
    const m3 = Number(req.body.m3);
    const m4 = Number(req.body.m4);

    const total = m1+m2+m3+m4
    // res.send(` Thank you ${name} your email is ${email} and marks ${total}`)
    res.render("result",{marks : total})
})

app.listen(4321)