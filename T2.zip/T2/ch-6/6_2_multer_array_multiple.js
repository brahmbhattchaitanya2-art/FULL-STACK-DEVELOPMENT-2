const express = require("express")
const multer = require("multer")
const app = express()

app.use(express.static(__dirname, { index: "m1.html" }))

var store = multer.diskStorage({
    destination: "Lju",
    filename: function (req, file, cb) { cb(null, file.originalname) }
})
var upload = multer({ storage: store })

app.post("/upload", upload.array("mypic",(5)), (req, res) => {
    const file = req.files
    if (file) {
        for( i of file)

        res.write("<h1>file<span style='color:red'>" + i.originalname + "</span>has been uploaded in <span style='color:red'>" + i.destination + "</span>folder")
            
        

        }
        else{
            res.send()
        }

        

        }

)
app.listen(6002)