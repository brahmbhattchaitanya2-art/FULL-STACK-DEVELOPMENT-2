const nodemailer = require("nodemailer");

let transporter = nodemailer.createTransport({
    host: "smtp.gmail.com",
    port: 465,
    secure: true, // true for 465
    auth: {
        user: "shichan132@gmail.com",
        pass: "bsjq fvhn htev mktu" // use real app password
    }
});

let mailOptions = {
    from: "shichan132@gmail.com",
    to: "dkdk14383@gmail.com",
    subject: "Hello",
    text: "Test Mail",
    html: "Testing node mailer,<h1>Effect of h1</h1>"
};

transporter.sendMail(mailOptions, (err, info) => {
    if (err) {
        console.log(err);
    } else {
        console.log("Email sent:", info.response);
    }
});





