// devlop a web appliction useing express 
//  and ejs that alloes the user to enter a 
// students name and makrs thought a form after submio
//  the entr diplay and ditermet result 
// if marks are 40 abouv show pass in green color 
// other wish shoew in red color "faile"

var express = require("express")
var app = express()
app.set("view engine","ejs")
app.get("/", (req, res) => {
    res.render("form")
})
app.get("/result", (req, res) => {
    var name = req.query.name
    var marks = parseInt(req.query.marks)

    res.render("result", { name, marks })
})
app.listen(3211, () => {
    console.log("Server running at http://localhost:3211")
})


