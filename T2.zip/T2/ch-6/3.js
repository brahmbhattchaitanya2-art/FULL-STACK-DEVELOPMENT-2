
// devploe a webappliction unuinf express and ejs to accpect makrs to 4 test (t1,t2,t3,t4),
// ecch of 25 makr thpought a form use
// display all mark in tebuler formet with totel marsk
// and dittermin the resul 
// if the totel 35 or more diplay in gress color 
// else red 



const express = require("express");
const app = express();

app.set("view engine", "ejs");
app.get("/", (req, res) => {
    res.render("mark");
});
app.get("/result", (req, res) => {
    let t1 = parseInt(req.query.t1)
    let t2 = parseInt(req.query.t2)
    let t3 = parseInt(req.query.t3)
    let t4 = parseInt(req.query.t4) 

    let total = t1 + t2 + t3 + t4;

    

    res.render("result2", {
        t1, t2, t3, t4, total,
    });
});

app.listen(3221, () => {
    console.log("Server running at http://localhost:3221")
})


