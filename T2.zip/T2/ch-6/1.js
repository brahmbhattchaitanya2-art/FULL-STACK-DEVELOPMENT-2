var express = require("express")
var app = express()

app.set("view engine","ejs")

app.get("/",(req,res)=>
{
    res.render("1")
})

app.listen(3211, () => {
  console.log(`Server running at http://localhost:3211`);
});